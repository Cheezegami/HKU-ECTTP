class Controls() :
    #Right, Left, Down, Up, Special.
    #Keyboard.
    String_controls = ["D","A","S","W"," "]
    String_altControls = ["d","a","s","w","c"]